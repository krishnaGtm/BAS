﻿/// <autosync enabled="true" />
/// <reference path="bas-min.js" />
/// <reference path="index.bundle.js" />
/// <reference path="indexscrolling.bundle.js" />
